//
//  CowpayFramework.h
//  CowpayFramework
//
//  Created by ahmed bassiouny on 9/18/21.
//

#import <Foundation/Foundation.h>

//! Project version number for CowpayFramework.
FOUNDATION_EXPORT double CowpayFrameworkVersionNumber;

//! Project version string for CowpayFramework.
FOUNDATION_EXPORT const unsigned char CowpayFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CowpayFramework/PublicHeader.h>


